import React, { useState } from "react";
import "./App.css";

const API_BASE = "http://localhost:8000";

export default function App() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const handleFile = (e) => {
    const f = e.target.files[0];

    if (!f) return;

    setFile(f);

    if (!f.name.toLowerCase().endsWith(".dcm")) {
      setPreview(URL.createObjectURL(f));
    } else {
      setPreview(null);
    }

    setResult(null);
    setError("");
  };

  const handleAnalyze = async () => {
    if (!file) return;

    setLoading(true);
    setError("");

    const fd = new FormData();
    fd.append("file", file);

    try {
      const res = await fetch(
        `${API_BASE}/analyze`,
        {
          method: "POST",
          body: fd,
        }
      );

      const data = await res.json();

      setResult(data);
    } catch {
      setError(
        "Analysis failed. Please check that the server is running."
      );
    } finally {
      setLoading(false);
    }
  };

  const downloadPDF = async () => {
    if (!file) return;

    const fd = new FormData();
    fd.append("file", file);

    const res = await fetch(
      `${API_BASE}/generate-pdf`,
      {
        method: "POST",
        body: fd,
      }
    );

    const blob = await res.blob();

    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");

    a.href = url;
    a.download = "brain-tumor-report.pdf";

    a.click();
  };
  const askQuestion = async () => {
  if (!question.trim()) return;

  setChatLoading(true);

  try {
    const res = await fetch(`${API_BASE}/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        question,
        tumor_type: result?.tumor_type,
        severity: result?.severity,
        tumor_location: result?.tumor_location,
        tumor_area_percent: result?.tumor_area_percent,
      }),
    });

    const data = await res.json();

    setAnswer(data.answer);
  } catch (err) {
    setAnswer("Unable to contact AI assistant.");
  } finally {
    setChatLoading(false);
  }
};
  return (
    <div className="app-wrapper">

      <header className="header">
        <span className="header-eyebrow">
          Neural Imaging Analysis
        </span>

        <h1>
          Brain Tumor <span>Detection</span>
        </h1>

        <p className="header-sub">
          Upload an MRI scan to automatically
          detect, classify, and segment brain tumors.
        </p>
      </header>

      <div className="card">
        <div className="card-label">
          01 — Upload MRI Scan
        </div>

        <div
          className={`upload-zone ${
            file ? "has-file" : ""
          }`}
        >
          <input
            type="file"
            accept=".png,.jpg,.jpeg,.dcm"
            onChange={handleFile}
          />

          <div className="upload-icon">⊕</div>

          <span className="upload-title">
            {file
              ? "File ready"
              : "Drop your MRI scan here"}
          </span>

          {file ? (
            <span className="upload-filename">
              📄 {file.name}
            </span>
          ) : (
            <span className="upload-hint">
              PNG, JPG, JPEG, DICOM
            </span>
          )}
        </div>
      </div>

      {preview && (
        <div className="preview-wrap">
          <div className="preview-frame">
            <img
              src={preview}
              alt="MRI Preview"
              className="pre_img"
            />
            <span className="preview-badge">
              MRI · Input
            </span>
          </div>
        </div>
      )}

      <button
        className="btn-analyze"
        onClick={handleAnalyze}
        disabled={!file || loading}
      >
        {loading && <span className="spinner" />}
        {loading
          ? "Analyzing..."
          : "Analyze MRI"}
      </button>

      {error && (
        <div className="error-bar">
          ⚠ {error}
        </div>
      )}

      {result && (
        <div className="results-card">

          <div className="results-header">
            <h2>Analysis Report</h2>

            <span
              className={`status-pill ${
                result.tumor_detected
                  ? "detected"
                  : "clear"
              }`}
            >
              {result.tumor_detected
                ? "Tumor Detected"
                : "No Tumor"}
            </span>
          </div>

          <div className="results-body">

            <div className="stat-grid">

              <div className="stat-item">
                <div className="stat-label">
                  Detection
                </div>

                <div
                  className={`stat-value ${
                    result.tumor_detected
                      ? "red"
                      : "green"
                  }`}
                >
                  {result.tumor_detected
                    ? "Positive"
                    : "Negative"}
                </div>
              </div>

              <div className="stat-item">
                <div className="stat-label">
                  Confidence
                </div>

                <div className="stat-value accent">
                  {(
                    result.binary_confidence * 100
                  ).toFixed(1)}
                  %
                </div>
              </div>

              {result.tumor_detected && (
                <>
                  <div className="stat-item">
                    <div className="stat-label">
                      Tumor Type
                    </div>

                    <div className="stat-value">
                      {result.tumor_type}
                    </div>
                  </div>

                  <div className="stat-item">
                    <div className="stat-label">
                      Tumor Area
                    </div>

                    <div className="stat-value accent">
                      {result.tumor_area_percent}%
                    </div>
                  </div>

                  <div className="stat-item">
                    <div className="stat-label">
                      Severity
                    </div>

                    <div className="stat-value">
                      {result.severity}
                    </div>
                  </div>

                  <div className="stat-item">
                    <div className="stat-label">
                      Location
                    </div>

                    <div className="stat-value">
                      {result.tumor_location}
                    </div>
                  </div>
                </>
              )}
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 12,
              }}
            >
              <ConfBar
                label="Detection Confidence"
                value={result.binary_confidence}
              />

              {result.tumor_detected && (
                <ConfBar
                  label="Classification Confidence"
                  value={
                    result.multiclass_confidence
                  }
                />
              )}
            </div>

            {result.tumor_detected &&
              result.top_predictions && (
                <div
                  style={{
                    marginTop: 20,
                  }}
                >
                  <h3>
                    Top Predictions
                  </h3>

                  {result.top_predictions.map(
                    (item, idx) => (
                      <ConfBar
                        key={idx}
                        label={item.tumor}
                        value={item.probability}
                      />
                    )
                  )}
                </div>
              )}

            {result.tumor_detected && (
              <div className="scan-grid">

                <div className="scan-item">
                  <span className="scan-item-label">
                    Segmentation Mask
                  </span>

                  <div className="scan-item-frame">
                    <img
                      src={`data:image/png;base64,${result.mask_b64}`}
                      alt="mask"
                    />
                  </div>
                </div>

                <div className="scan-item">
                  <span className="scan-item-label">
                    Tumor Overlay
                  </span>

                  <div className="scan-item-frame">
                    <img
                      src={`data:image/png;base64,${result.overlay_b64}`}
                      alt="overlay"
                    />
                  </div>
                </div>
              </div>
            )}
            <div className="chat-card">

  <h3 className="chat-title">
    AI Medical Assistant
  </h3>

  <div className="chat-suggestions">

    <button
      className="suggestion-btn"
      onClick={() =>
        setQuestion(
          "Explain this MRI report in simple language"
        )
      }
    >
      Explain Report
    </button>

    <button
      className="suggestion-btn"
      onClick={() =>
        setQuestion(
          "How serious is this tumor?"
        )
      }
    >
      Severity
    </button>

    <button
      className="suggestion-btn"
      onClick={() =>
        setQuestion(
          "What treatments are available?"
        )
      }
    >
      Treatment
    </button>

  </div>

  <div className="chat-row">

    <input
      type="text"
      className="chat-input"
      placeholder="Ask about this MRI..."
      value={question}
      onChange={(e) =>
        setQuestion(e.target.value)
      }
    />

    <button
      className="chat-btn"
      onClick={askQuestion}
      disabled={chatLoading}
    >
      {chatLoading
        ? "Thinking..."
        : "Ask"}
    </button>

  </div>

  {answer && (
    <div className="chat-answer">
      {answer}
    </div>
  )}

</div>
            <div>
              <button
                className="btn-download"
                onClick={downloadPDF}
              >
                ↓ Download PDF Report
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}

function ConfBar({ label, value }) {
  return (
    <div className="conf-row">
      <div className="conf-row-header">
        <span>{label}</span>

        <span>
          {(value * 100).toFixed(1)}%
        </span>
      </div>

      <div className="conf-bar-track">
        <div
          className="conf-bar-fill"
          style={{
            width: `${(
              value * 100
            ).toFixed(1)}%`,
          }}
        />
      </div>
    </div>
  );
}